// import syntaxtree.*;
// import visitor.*;

// public class Main {
//    public static void main(String [] args) {
//       try {
//          Node root = new MiniJavaParser(System.in).Goal();
//          System.out.println("Program parsed successfully");
//          root.accept(new GJNoArguDepthFirst()); // Your assignment part is invoked here.
//       }
//       catch (ParseException e) {
//          System.out.println(e.toString());
//       }
//    }
// } 


import syntaxtree.*;
import visitor.*;
import java.util.*;

public class P3 {
   public static void main(String [] args) {
      try {
         Node root = new MiniJavaParser(System.in).Goal();
         GJNoArguDepthFirst df=new GJNoArguDepthFirst();
         root.accept(df);
         GJDepthFirst1 df1=new GJDepthFirst1();
         root.accept(df1,null);
         // GJDepthFirst df = new GJDepthFirst();
         // Object value = root.accept(df, null); // Your assignment part is invoked here.

      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
}
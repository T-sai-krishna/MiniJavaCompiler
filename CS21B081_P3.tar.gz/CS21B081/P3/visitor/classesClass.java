package visitor;

import syntaxtree.*;
import java.util.*;
 public class classesClass
   {
      String name;
      String parent;
      HashMap <String,String> classvars=new HashMap<String,String>();
      HashMap <String,functions> classfuncs=new HashMap<String,functions>();
      HashMap <String,Integer> classvarstemps=new HashMap<String,Integer>();
      HashMap <String,Integer> classfuncstemps=new HashMap<String,Integer>();
   }
package visitor;

import syntaxtree.*;
import java.util.*;

public class functions {
    String name;
    String fclass;
    String ret;
    int nargs;
    int temp = 0;
    int invars;
    HashMap<String, Integer> numbering = new HashMap<String, Integer>();
    HashMap<String, String> args = new HashMap<String, String>();
    HashMap<String, Integer> argstemps = new HashMap<String, Integer>();
    HashMap<String, String> funcvars = new HashMap<String, String>();
    HashMap<String, Integer> funcvarstemps = new HashMap<String, Integer>();
}

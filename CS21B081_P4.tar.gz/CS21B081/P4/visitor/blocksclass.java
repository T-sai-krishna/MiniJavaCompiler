package visitor;

import java.util.*;
public class blocksclass {
    // Integer defined=-1;
    Set<Integer> defined=new HashSet<Integer>();//we should use sets here
    Set<Integer> used=new HashSet<Integer>();
    Set<Integer> in=new HashSet<Integer>();
    Set<Integer> out=new HashSet<Integer>();
    Set<Integer> succ=new HashSet<Integer>();

}

package visitor;
import java.util.*;
public class functionsclass {
    String functionName;
    Map<Integer, blocksclass> blocks = new HashMap<Integer, blocksclass>();
    ArrayList<Integer> temps = new ArrayList<Integer>();
    Map<Integer,Integer>startTime=new HashMap<Integer,Integer>();
    Map<Integer, Integer> endTime = new HashMap<Integer, Integer>();
    Map<Integer,Integer>registerAllocated=new HashMap<Integer, Integer>();
    // Map<Integer, Integer> spills = new HashMap<Integer, Integer>();
    ArrayList<Integer> spills = new ArrayList<Integer>();
    Map<Integer,Integer>spilledPos=new HashMap<Integer, Integer>();
}

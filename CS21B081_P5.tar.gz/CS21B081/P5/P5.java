import syntaxtree.*;
import visitor.*;

public class P5 {
   public static void main(String[] args) {
      try {
         Node root = new MiniRAParser(System.in).Goal();
         // System.out.println("Program parsed successfully");
         root.accept(new Firstpass(), null); // Your assignment part is invoked here.
         // root.accept(new Secondpass(), null);
         // root.accept(new Thirdpass(), null);
      } catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
}
